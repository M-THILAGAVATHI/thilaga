<?php
include 'dbcon.php';
$sql="create table emp_tbl(emp_id int,emp_name varchar(30),emp_title varchar(100),emp_category varchar(5),emp_tag varchar(10),emp_dob varchar(30),emp_phno varchar(30),emp_email varchar(30),emp_address varchar(50),emp_uname varchar(30),emp_upass varchar(30))";
mysqli_query($con,$sql);
echo "table created";
?>