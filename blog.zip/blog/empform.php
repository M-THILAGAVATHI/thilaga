<html>
<body>
<form action=form_prc.php>
<pre>
id:<input type=text name=emp_id>
name:<input type=text name=emp_name>
dob:<input type=date name=emp_dob>
phno:<input type=text name=emp_phno>
email:<input type=text name=emp_email>
address:<textarea name=emp_addr></textarea>
uname:<input type=text name=emp_uname>
upass:<input type=text name=emp_upass>
<input type=submit value=login>
</pre>
</form>
</body>
</html>