<html>
<body id=bcolor>
<head><link type="text/css" href="editprc.css" rel="stylesheet"></head>
<div id=head><h1>update your details</h1></div>
<?php
include 'dbcon.php';
$id=$_REQUEST['id'];
$sql="select * from emp_tbl where emp_id=$id";
$res=mysqli_query($con,$sql);
$row=mysqli_fetch_array($res);
?>

<form action=edit_prc.php>

<table id=one>
<tr><td>id</td><td>:</td><td><input type=text name=emp_id value=<?php echo $row[0];?> readonly id=two></td></tr>
<tr><td>name</td><td>:</td><td><input type=text name=emp_name value=<?php echo $row[1];?> id=three></td></tr>
<tr><td>title</td><td>:</td><td><input type=text name=emp_title value=<?php echo $row[2];?> id=four></td></tr>
<tr><td>category</td><td>:</td><td><td><select name="emp_category" value=<?php echo $row[3];?> id=five><option>Technology</option>
	<option>Travel</option>
	<option>Events</option></select></td></tr>
<tr><td>tag</td><td>:</td><td><td><select name="emp_tag" value=<?php echo $row[4];?> id=six><option>Select</option>
	<option>Airline</option>
	<option>Hotel</option>
	<option>Package</option>
	<option>Holidays</option>
	<option>Deals</option></select></td></tr>
<tr><td>dob</td><td>:</td><td><input type=date name=emp_dob value=<?php echo $row[5];?> id=sevenr></td></tr>
<tr><td>phno</td><td>:</td><td><input type=text name=emp_phno value=<?php echo $row[6];?> id=eight></td></tr>
<tr><td>email</td><td>:</td><td><input type=text name=emp_email value=<?php echo $row[7];?> id=nine></td></tr>
<tr><td>address</td><td>:</td><td><textarea name=emp_addr id=nine><?php echo $row[8];?></textarea></td></tr>
<tr><td>uname</td><td>:</td><td><input type=text name=emp_uname value=<?php echo $row[9];?> id=ten></td></tr>
<tr><td>upass</td><td>:</td><td><input type=text name=emp_upass value=<?php echo $row[10];?> id=eight></td></tr>
<tr colspan=4><td ><input type=submit value=update id=upd></td></tr>
</table>
</form> 
</body>
</html>