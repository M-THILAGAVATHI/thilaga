<html>
<body>
<head>
<link type="text/css" href="login.css" rel="stylesheet">
</head>
<center><h1 id=title>Login</h1></center>
<form action="login_prc.php">
<pre id=form>
Username:<input type=text name=emp_uname id=uname>
Password:<input type=text name=emp_upass id=upass>
<input type=submit value=Login id=submit>
</pre>
</form>
</body>
</html>