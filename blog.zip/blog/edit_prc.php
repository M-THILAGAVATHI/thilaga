
<?php
include 'dbcon.php';
$id=$_REQUEST['emp_id'];
$name=$_REQUEST['emp_name'];
$title=$_REQUEST['emp_title'];
$category=$_REQUEST['emp_category'];
$tag=$_REQUEST['emp_tag'];
$dob=$_REQUEST['emp_dob'];
$phno=$_REQUEST['emp_phno'];
$email=$_REQUEST['emp_email'];
$address=$_REQUEST['emp_addr'];
$uname=$_REQUEST['emp_uname'];
$upass=$_REQUEST['emp_upass'];
$sql="update emp_tbl set emp_name='$name',emp_dob='$dob',emp_title='$title',emp_category='$category',
emp_tag='emp_tag',emp_phno='$phno',emp_email='$email',emp_address='$address',emp_uname='$uname',emp_upass='$upass' where emp_id=$id";
mysqli_query($con,$sql);
echo "updated";
?>
