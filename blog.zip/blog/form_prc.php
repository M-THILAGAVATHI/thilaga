<?php
include 'dbcon.php';
$id=$_REQUEST['emp_id'];
$name=$_REQUEST['emp_name'];
$dob=$_REQUEST['emp_dob'];
$phno=$_REQUEST['emp_phno'];
$email=$_REQUEST['emp_email'];
$address=$_REQUEST['emp_addr'];
$uname=$_REQUEST['emp_uname'];
$upass=$_REQUEST['emp_upass'];

$sql="insert into emp_tbl values('$id','$name','$dob','$phno','$email','$address','$uname','$upass')";
mysqli_query($con,$sql);
echo "insert successful";
?>