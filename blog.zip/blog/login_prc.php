<?php
include 'dbcon.php'; 
$uname=$_REQUEST['emp_uname'];
$upass=$_REQUEST['emp_upass'];
$sql="select * from emp_tbl where emp_uname='".$uname."' and emp_upass='".$upass."'";
$res=mysqli_query($con,$sql);
$row=mysqli_fetch_array($res);

if(($row[9]=="")&&($row[10]==""))
{
echo "<script>alert('invalid login');location='login.php';</script>";
}
elseif(($row[9]==$uname)&&($row[10]==$upass))
{
	echo "<script>alert('login successful');location='view.php';</script>";
}
else
{
echo "<script>alert('invalid login');location='login.php';</script>";	
}?>