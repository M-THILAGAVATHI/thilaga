<?php
include 'dbcon.php';
$id=$_REQUEST['id'];
$sql="delete from emp_tbl where emp_id=$id";
mysqli_query($con,$sql);
echo "";
?>