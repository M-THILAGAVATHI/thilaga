<html>
<body bgcolor="pink">
<form action="form_prc.php">
    <center><font color="darkgreen"> <h1>Add Your Details</h1></font></center><hr size="3px" color="red" width="300px">
<center><table>
<tr>
    <td>id </td>
    <td>:</td>
    <td><input type="text" name="emp_id"></td>
</tr>
    <tr>
        <td>name</td>
        <td>:</td>
        <td><input type="text" name="emp_name"></td>
    </tr>
    <tr>
        <td>dob </td>
        <td>:</td>
        <td><input type="date" name="emp_dob"></td>
    </tr>
    <tr>
        <td>phno</td>
        <td>:</td>
        <td><input type="text" name="emp_phno"></td>
    </tr>
    <tr>
        <td>email</td>
        <td>:</td>
        <td><input type="text" name="emp_email"></td>
    </tr>
    <tr>
       <td>address</td>
           <td>:</td>
        <td><textarea name="emp_addr"></textarea></td>
    </tr>
    <tr>
        <td>uname</td>
        <td>:</td>
        <td><input type="text" name="emp_uname"></td></tr>
    <tr>
        <td>upass</td>
    <td>:</td>
    <td><input type="text" name="emp_upass"></td>
    </tr>
    <tr>
        <td><input type="submit" value="login"></td></tr>
    
</table>
    </center>
</form>
</body>
</html>