<?php
$host="localhost";
$uname="root";
$upass="";
$db="cms";
$con=mysqli_connect($host,$uname,$upass,$db);
?>

