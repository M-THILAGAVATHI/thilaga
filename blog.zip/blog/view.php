<?php
include 'dbcon.php';
$sql="select * from emp_tbl";
$res=mysqli_query($con,$sql);
?>
<html><head><link type="text/css" href="view.css" rel="stylesheet"></head><h1 id=title>Employee details</h1>
<table border=1px cellspacing=0px id=table>
<tr id=row1>
	<td>id</td>
	<td>name</td>
	<td>view</td>
	<td>edit</td>
	<td>delete</td>
</tr>
<?php
while($row=mysqli_fetch_array($res))
{
echo "<tr>
<td>$row[0]</td>
<td id=uid>$row[1]</td>
<td><a href=view_prc.php?id=$row[0] id=row2>view</a></td>
<td><a href=edit.php?id=$row[0] id=row3>edit</a></td>
<td><a href=delete.php?id=$row[0] id=row4>delete</a></td>
<tr>";
}
?>
</table>
	