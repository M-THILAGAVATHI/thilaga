<html>
<body id=bcolor>
<?php
include 'dbcon.php';
$id=$_REQUEST['id'];
$sql="select * from emp_tbl where emp_id=$id";
$res=mysqli_query($con,$sql);
?>
<head><link type="text/css" href="viewprc.css" rel="stylesheet"></head>
<div id=head><h1>Welcome..</h1></div>
<table border=1px cellspacing=0px id=table>
<tr id=one>
	<td>id</td>
	<td>name</td>
    <td>title</td>
    <td>category</td>
    <td>tag</td>
	<td>dob</td>
	<td>phno</td>
	<td>email</td>
	<td>address</td>
	<td>uname</td>
	<td>upass</td>
</tr>

<?php
while($row=mysqli_fetch_array($res))
{
echo "<tr id=two>
<td>$row[0]</td>
<td>$row[1]</td>
<td>$row[2]</td>
<td>$row[3]</td>
<td>$row[4]</td>
<td>$row[5]</td>
<td>$row[6]</td>
<td>$row[7]</td>
<td>$row[8]</td>
<td>$row[9]</td>
<td>$row[10]</td>
</tr>";
}
?>
</table>
</body>
</html>