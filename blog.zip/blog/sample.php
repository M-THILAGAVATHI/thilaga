<html>
<body bgcolor="pink">
<form action="sample-form_prc.php">
    <center><font color="darkgreen"> <h1>Add Your Details</h1></font></center><hr size="3px" color="red" width="300px">
<center><table>
<tr>
    <td>id </td>
    <td>:</td>
    <td><input type="text" name="emp_id"></td>
</tr>
<td>Author Name </td>
    <td>:</td>
    <td><input type="text" name="emp_name"></td>
</tr>
<tr>
    <td>Title </td>
    <td>:</td>
    <td><input type="text" name="emp_title"></td>
</tr>
    <tr>
	<td>Category</td>
	<td>:</td>
	<td><select name="emp_category"><option>Technology</option>
	<option>Travel</option>
	<option>Events</option></select></td>
        </tr>
<tr>
	<td>Tags</td>
	<td>:</td>
	<td><select name="emp_tags"><option>Select</option>
	<option>Airline</option>
	<option>Hotel</option>
	<option>Package</option>
	<option>Holidays</option>
	<option>Deals</option></select></td>
</tr>
    <tr>
        <td>Date </td>
        <td>:</td>
        <td><input type="date" name="emp_dob"></td>
    </tr>
    <tr>
        <td>phno</td>
        <td>:</td>
        <td><input type="text" name="emp_phno"></td>
    </tr>
    <tr>
        <td>email</td>
        <td>:</td>
        <td><input type="text" name="emp_email"></td>
    </tr>
    <tr>
       <td>address</td>
           <td>:</td>
        <td><textarea name="emp_addr"></textarea></td>
    </tr>
    <tr>
        <td>uname</td>
        <td>:</td>
        <td><input type="text" name="emp_uname"></td></tr>
    <tr>
        <td>upass</td>
    <td>:</td>
    <td><input type="text" name="emp_upass"></td>
    </tr>
    <tr>
        <td><input type="submit" value="login"></td></tr>
    
</table>
    </center>
</form>
</body>
</html>