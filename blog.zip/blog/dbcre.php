<?php
$con=mysqli_connect("localhost","root","");
$sql="create database cms";
mysqli_query($con,$sql);
echo "database created";
?>
